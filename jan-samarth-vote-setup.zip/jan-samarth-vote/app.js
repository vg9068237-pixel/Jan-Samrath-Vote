/* Jan Samarth Vote — frontend demo.
   IMPORTANT: votes and polls here are stored only in this browser (localStorage).
   For public multi-user voting, connect a real backend/database and server-side protections. */
const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const demoPolls = [
 {id:"demo-priority",category:"स्थानीय मुद्दे / Local issues",question:"आपके क्षेत्र की सबसे बड़ी प्राथमिकता क्या होनी चाहिए?",options:["सड़क और पानी","शिक्षा","स्वास्थ्य सेवाएँ","रोजगार"],votes:[18,14,9,12],demo:true},
 {id:"demo-voter",category:"राजस्थान / Rajasthan",question:"चुनाव की जानकारी के लिए आप किस विषय को पहले देखना चाहेंगे?",options:["मतदान की तारीखें","उम्मीदवारों की जानकारी","वोटर गाइड","आधिकारिक परिणाम"],votes:[12,15,8,17],demo:true},
 {id:"demo-community",category:"जनमत / Public opinion",question:"स्थानीय विकास पर राय साझा करने का सबसे उपयोगी तरीका क्या है?",options:["ऑनलाइन सर्वे","जनसभा","स्थानीय प्रतिनिधि से संपर्क"],votes:[20,11,7],demo:true}
];
function readPolls(){try{const p=JSON.parse(localStorage.getItem("jsv_polls"));return Array.isArray(p)?p:demoPolls.map(x=>({...x,options:[...x.options],votes:[...x.votes]}));}catch{return demoPolls.map(x=>({...x,options:[...x.options],votes:[...x.votes]}));}}
function savePolls(p){localStorage.setItem("jsv_polls",JSON.stringify(p));}
let polls=readPolls();let activePoll=null;
const votedKey=id=>"jsv_voted_"+id;
function total(p){return p.votes.reduce((a,b)=>a+(Number(b)||0),0);}
function renderPolls(filter=""){
 const grid=$("#pollGrid");const f=filter.trim().toLowerCase();
 const list=polls.filter(p=>(p.question+" "+p.category).toLowerCase().includes(f));
 if(!list.length){grid.innerHTML='<div class="empty">कोई पोल नहीं मिला / No polls found.</div>';return;}
 grid.innerHTML=list.map(p=>`<article class="poll-card"><div class="poll-meta"><span class="pill">${escapeHtml(p.category)}</span><span>${p.demo?"डेमो / Demo":"कम्युनिटी / Community"}</span></div><h3>${escapeHtml(p.question)}</h3><p>🗳️ ${total(p).toLocaleString("en-IN")} वोट · ${p.options.length} विकल्प</p><button class="button" data-vote="${p.id}">${localStorage.getItem(votedKey(p.id))?"परिणाम देखें / View results":"वोट करें / Vote now"}</button><button class="button secondary" data-share="${p.id}">लिंक शेयर करें / Share poll</button></article>`).join("");
 $$("[data-vote]",grid).forEach(b=>b.addEventListener("click",()=>openPoll(b.dataset.vote)));
 $$("[data-share]",grid).forEach(b=>b.addEventListener("click",()=>sharePoll(b.dataset.share)));
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function openPoll(id){activePoll=polls.find(p=>p.id===id);if(!activePoll)return;$("#dialogQuestion").textContent=activePoll.question;renderDialog();$("#voteDialog").showModal();}
function renderDialog(){
 const p=activePoll, already=!!localStorage.getItem(votedKey(p.id)), n=total(p);
 if(already){$("#dialogBody").innerHTML=`<p class="muted">आपने इस ब्राउज़र से पहले ही वोट दिया है। यह सीमा केवल इसी डिवाइस/ब्राउज़र में लागू है।</p>${p.options.map((o,i)=>`<div class="result-row"><div class="result-top"><span>${escapeHtml(o)}</span><b>${n?Math.round(p.votes[i]/n*100):0}% · ${p.votes[i]} वोट</b></div><div class="bar"><span style="width:${n?p.votes[i]/n*100:0}%"></span></div></div>`).join("")}<div class="dialog-actions"><button class="button share-btn" id="shareFromDialog">WhatsApp / Share</button></div>`;$("#shareFromDialog").onclick=()=>sharePoll(p.id);return;}
 $("#dialogBody").innerHTML=`<p class="muted">एक विकल्प चुनें। अनौपचारिक जनमत सर्वे — आधिकारिक चुनाव परिणाम नहीं।</p><form id="voteForm">${p.options.map((o,i)=>`<label class="choice"><input type="radio" name="option" value="${i}" required><span>${escapeHtml(o)}</span></label>`).join("")}<div class="dialog-actions"><button class="button primary" type="submit">अपना वोट दें / Submit vote</button><button class="button share-btn" type="button" id="shareFromDialog">Share</button></div><p class="form-message" id="voteMessage" role="status"></p></form>`;
 $("#shareFromDialog").onclick=()=>sharePoll(p.id);
 $("#voteForm").onsubmit=e=>{e.preventDefault();const chosen=$('input[name="option"]:checked',e.currentTarget);if(!chosen)return;const idx=Number(chosen.value);p.votes[idx]=(Number(p.votes[idx])||0)+1;localStorage.setItem(votedKey(p.id),"yes");savePolls(polls);renderPolls($("#searchInput").value);renderDialog();};
}
async function sharePoll(id){const url=new URL(location.href);url.hash="poll-"+id;const p=polls.find(x=>x.id===id);const data={title:"Jan Samarth Vote",text:p?.question||"जन समर्थन वोट पर पोल देखें",url:url.href};try{if(navigator.share)await navigator.share(data);else if(navigator.clipboard){await navigator.clipboard.writeText(url.href);alert("पोल लिंक कॉपी हो गया। / Poll link copied.");}else prompt("इस लिंक को कॉपी करें:",url.href);}catch(e){}}
$("#searchInput").addEventListener("input",e=>renderPolls(e.target.value));
$("#createForm").addEventListener("submit",e=>{e.preventDefault();const question=$("#pollQuestion").value.trim();const options=$$(".poll-option").map(x=>x.value.trim()).filter(Boolean);if(options.length<2){$("#createMessage").textContent="कम से कम 2 विकल्प डालें।";return;}const p={id:"poll-"+Date.now().toString(36),category:$("#pollCategory").value,question,options,votes:options.map(()=>0),demo:false};polls.unshift(p);savePolls(polls);renderPolls($("#searchInput").value);e.target.reset();$("#createMessage").textContent="पोल इस ब्राउज़र में बन गया है। सभी लोगों के साथ साझा करने के लिए डेटाबेस सेटअप जरूरी है।";location.hash="#polls";});
$("#menuBtn").addEventListener("click",()=>$("#nav").classList.toggle("open"));
$$("nav a").forEach(a=>a.addEventListener("click",()=>$("#nav").classList.remove("open")));
$("#year").textContent=new Date().getFullYear();
renderPolls();
